import React from "react";
import { useClientes } from "../hooks/useClientes";
import { FilterBar } from "../components/FilterBar";
import { Pagination } from "../components/Pagination";

export const Home: React.FC = () => {
  const {
    currentClientes,
    totalPages,
    page,
    setPage,
    search,
    setSearch,
  } = useClientes();

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-semibold mb-4">Clientes</h1>

      <FilterBar
        search={search}
        onSearch={(value) => {
          setSearch(value);
          setPage(1); // reseta pra página 1 ao buscar
        }}
      />

      <table className="min-w-full table-auto mt-4 border-collapse">
        <thead>
          <tr>
            <th className="px-4 py-2 border-b">Nome</th>
            <th className="px-4 py-2 border-b">CPF/CNPJ</th>
            <th className="px-4 py-2 border-b">Renda Anual</th>
          </tr>
        </thead>
        <tbody>
          {currentClientes.map((c) => (
            <tr key={c.id} className="hover:bg-gray-50">
              <td className="px-4 py-2">{c.nome}</td>
              <td className="px-4 py-2">{c.cpfCnpj}</td>
              <td className="px-4 py-2">
                {c.rendaAnual.toLocaleString("pt-BR", {
                  style: "currency",
                  currency: "BRL",
                })}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="mt-4">
        <Pagination current={page} total={totalPages} onChange={setPage} />
      </div>
    </div>
  );
};
