import React from 'react';

export const PaginaCliente = () => {
    return <div>Detalhes do Cliente</div>;
  };