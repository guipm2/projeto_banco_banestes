import React from 'react';
import { Routes, Route, Link } from 'react-router-dom';
import { Home } from './pages/Home';
import { PaginaCliente } from './pages/PaginaCliente'; // Ensure this matches the export in PaginaCliente.tsx

export default function App() {
  return (
    <div>
      <header className="bg-blue-600 text-white p-4">
        <Link to="/" className="text-xl font-bold">🏦 Meu Banco</Link>
      </header>
      <main className="p-4">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="clientes/:id" element={<PaginaCliente />} />
        </Routes>
      </main>
    </div>
  );
}
